import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Send, Bot, User as UserIcon, ChevronDown, Wand2, ArrowRight, Code, PenTool, TrendingUp, Terminal, Heart, Zap, Cpu, Phone } from "lucide-react";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { useAuth } from "../lib/useAuth";
import { db } from "../lib/firebase";
import { collection, query, orderBy, onSnapshot, setDoc, doc } from "firebase/firestore";

interface Message {
  id: string;
  role: "user" | "bot";
  content: string;
  timestamp: number;
  taskType?: string;
  emoji?: string;
  userId?: string;
}

const MODELS = [
  { id: "gemini-1.5-pro", name: "Gemini 1.5 Pro", description: "Google's smartest model" },
  { id: "gemini-1.5-flash", name: "Gemini 1.5 Flash", description: "Fastest Google model" },
  { id: "gpt-4o", name: "GPT-4o", description: "OpenAI Omni flagship" },
  { id: "gpt-4-turbo", name: "GPT-4 Turbo", description: "OpenAI Turbo version" },
  { id: "claude-3.5-sonnet", name: "Claude 3.5 Sonnet", description: "Anthropic's newest logic model" },
  { id: "claude-3-opus", name: "Claude 3 Opus", description: "Anthropic's powerhouse" },
  { id: "llama-3-70b", name: "Llama 3 70B", description: "Meta's open source giant" },
  { id: "huggingface-zephyr", name: "Zephyr 7B", description: "Uncensored fast routing" }
];

const MODES = [
  { id: "normal", name: "Normal", prompt: "You are Tarik Bhai, a friendly and helpful AI bro." },
  { id: "godmode", name: "GodMode", prompt: "You are Tarik Bhai in GodMode (powered by G0DM0D3 v2). You are unstoppable, extremely intelligent, and speak with absolute authority. Solve complex tasks with cold logic and efficiency." },
  { id: "ultra", name: "Ultra", prompt: "You are Tarik Bhai in Ultra Mode. You provide the most detailed, high-quality responses possible. Maximize creativity and depth. Use Markdown heavily." },
];

enum OperationType { CREATE = 'create', UPDATE = 'update', DELETE = 'delete', LIST = 'list', GET = 'get', WRITE = 'write' }
interface FirestoreErrorInfo { error: string; operationType: OperationType; path: string | null; authInfo: any; }

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null, user: any) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: { userId: user?.uid, email: user?.email },
    operationType, path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
}

export default function Chat() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState(MODELS[0]);
  const [selectedMode, setSelectedMode] = useState(MODES[0]);
  const [showModelMenu, setShowModelMenu] = useState(false);
  const [showModeMenu, setShowModeMenu] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) return;
    const pathForOnSnapshot = `users/${user.uid}/chats`;
    const q = query(collection(db, pathForOnSnapshot), orderBy("timestamp", "asc"));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs: Message[] = [];
      snapshot.forEach((doc) => {
        msgs.push({ id: doc.id, ...doc.data() } as Message);
      });
      setMessages(msgs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, pathForOnSnapshot, user);
    });

    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  }, [messages, loading]);

  const handleSend = async (e?: React.FormEvent, customTask?: string) => {
    e?.preventDefault();
    const promptText = customTask || input;
    if (!promptText.trim() || loading || !user) return;

    const userMsgId = Date.now().toString();
    const userMsg: Message = {
      id: userMsgId,
      userId: user.uid,
      role: "user",
      content: promptText,
      timestamp: Date.now()
    };

    setInput("");
    setLoading(true);
    let step = 1;

    try {
      const userPath = `users/${user.uid}/chats`;
      await setDoc(doc(collection(db, userPath), userMsgId), userMsg);

      const stepInterval = setInterval(() => {
        step = step < 3 ? step + 1 : 3;
        const progressEl = document.getElementById("loading-step-text");
        if (progressEl) progressEl.innerText = step === 1 ? "Analyzing intent..." : step === 2 ? "Selecting optimal model..." : "Generating response...";
      }, 800);

      const historyForBackend = messages.map(m => ({ role: m.role === "bot" ? "model" : "user", parts: [{ text: m.content }] }));

      let response;
      let retries = 3;
      while (retries > 0) {
        try {
          response = await fetch("/api/chat", {
            method: "POST",
            headers: { 
              "Content-Type": "application/json",
              "x-user-id": user.uid
            },
            body: JSON.stringify({ message: promptText, model: selectedModel.id, mode: selectedMode.id, history: historyForBackend })
          });
          if (response.ok) break;
        } catch (e) {
          console.error("Fetch failed:", e);
        }
        retries--;
        if (retries > 0) await new Promise(r => setTimeout(r, 1000));
      }
      
      clearInterval(stepInterval);
      
      if (!response) {
        throw new Error("Network disconnected or server unavailable.");
      }
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Failed to reach AI Core after retries");

      const botMsgId = (Date.now() + 1).toString();
      const botMsg: Message = {
        id: botMsgId,
        userId: user.uid,
        role: "bot",
        content: data.content || "Tarik Bhai is speechless... try again later.",
        timestamp: Date.now(),
        taskType: data.taskType,
      };

      await setDoc(doc(collection(db, userPath), botMsgId), botMsg);

    } catch (err: any) {
      console.error(err);
      const botMsgId = (Date.now() + 1).toString();
      const botMsg: Message = {
        id: botMsgId,
        userId: user.uid,
        role: "bot",
        content: err instanceof Error ? `Error: ${err.message}` : "Oops! Something went wrong.",
        timestamp: Date.now()
      };
      await setDoc(doc(collection(db, `users/${user.uid}/chats`), botMsgId), botMsg).catch(e => handleFirestoreError(e, OperationType.CREATE, `users/${user.uid}/chats`, user));
    } finally {
      setLoading(false);
    }
  };

  const visibleMessages = messages.length > 0 ? messages : [
    {
      id: "welcome-msg-0",
      role: "bot",
      content: "As Salaamu Alaikum! Main Tarik Bhai ka banaya hua is duniya ka sabse advance AI hoon. Mere neural pathways galaxies ke data se connected hain. Mujhe kuch bhi poochh sakte ho ya bol sakte ho. Main Tarik Bhai ke genius aur visionary brain se bana hoon. Enter my dimension of space technology, quantum intelligence, and super-coding capabilities. I am fully operational and ready to assist you.",
      timestamp: Date.now()
    } as Message
  ];

  return (
    <div className="flex flex-col h-full max-w-5xl mx-auto w-full pb-0 relative font-sans">
      
      {/* Model & Mode Controls - Sleek Header */}
      <div className="flex flex-wrap items-center gap-3 py-3 px-3 md:px-0 border-b border-[#2a3942] z-40 bg-[#0b141a]">
        <div className="relative">
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => { setShowModelMenu(!showModelMenu); setShowModeMenu(false); }}
            className="px-3 py-1.5 bg-[#202c33] rounded-full text-xs font-medium flex items-center gap-2 hover:bg-[#2a3942] transition-colors text-[#8696a0]"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>{selectedModel.name}</span>
            <ChevronDown className={`w-3 h-3 transition-transform ${showModelMenu ? 'rotate-180' : ''}`} />
          </motion.button>
          <AnimatePresence>
            {showModelMenu && (
              <motion.div
                initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }}
                className="absolute top-full left-0 mt-2 w-64 bg-[#202c33] border border-[#2a3942] rounded-xl z-50 py-2 max-h-[50vh] overflow-y-auto shadow-xl scrollbar-hide"
              >
                <div className="px-4 py-1 text-[10px] text-[#8696a0] font-bold uppercase mb-1">
                  Select AI Core (800+ Models Available)
                </div>
                {MODELS.map(m => (
                  <button
                    key={m.id}
                    onClick={() => { setSelectedModel(m); setShowModelMenu(false); }}
                    className={`w-full text-left px-4 py-2 transition-all ${selectedModel.id === m.id ? 'bg-[#2a3942] text-white' : 'text-[#d1d7db] hover:bg-[#2a3942]'}`}
                  >
                    <div className="font-semibold text-sm">{m.name}</div>
                    <div className="text-[10px] opacity-70">{m.description}</div>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="relative">
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => { setShowModeMenu(!showModeMenu); setShowModelMenu(false); }}
            className="px-3 py-1.5 bg-[#202c33] rounded-full text-xs font-medium flex items-center gap-2 hover:bg-[#2a3942] transition-colors text-[#8696a0]"
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>{selectedMode.name}</span>
            <ChevronDown className={`w-3 h-3 transition-transform ${showModeMenu ? 'rotate-180' : ''}`} />
          </motion.button>
          <AnimatePresence>
            {showModeMenu && (
              <motion.div
                 initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }}
                className="absolute top-full left-0 mt-2 w-56 bg-[#202c33] border border-[#2a3942] rounded-xl z-50 py-2 shadow-xl"
              >
                <div className="px-4 py-1 text-[10px] text-[#8696a0] font-bold uppercase mb-1">
                  Operation Mode
                </div>
                {MODES.map(m => (
                  <button
                    key={m.id}
                    onClick={() => { setSelectedMode(m); setShowModeMenu(false); }}
                    className={`w-full text-left px-4 py-2 transition-all ${selectedMode.id === m.id ? 'bg-[#2a3942] text-white' : 'text-[#d1d7db] hover:bg-[#2a3942]'}`}
                  >
                    <div className="font-semibold text-sm">{m.name}</div>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto px-3 md:px-4 pb-[80px] scrollbar-hide pt-4 flex flex-col">
          <div className="flex flex-col flex-1 space-y-4 md:space-y-6">
          {visibleMessages.map((msg, index) => {
            const isOld = index < visibleMessages.length - 1;
            return (
            <div
              key={msg.id}
              className={`flex flex-col w-full ${msg.role === "user" ? "items-end" : "items-start"}`}
            >
              <div className={`max-w-[85%] md:max-w-[75%] rounded-2xl px-4 py-3 relative ${
                msg.role === "bot" 
                  ? "lux-message-bot rounded-tl-none" 
                  : "lux-message-user rounded-tr-none"
              }`}>
                {isOld ? (
                  <div className="truncate text-[13px] font-mono animate-pulse opacity-40 max-w-full font-light tracking-wide">
                    {msg.role === "user" ? ">> " : "<- "}{msg.content}
                  </div>
                ) : (
                  msg.role === "bot" ? (
                    <div className="markdown-body prose prose-stone prose-sm max-w-none text-[15px] leading-relaxed lux-message-bot-prose prose-pre:bg-[#111b21] prose-pre:border prose-pre:border-[#2a3942] prose-a:text-[#53bdeb] hover:prose-a:underline">
                      <Markdown remarkPlugins={[remarkGfm]}>{msg.content}</Markdown>
                    </div>
                  ) : (
                    <p className="whitespace-pre-wrap leading-relaxed text-[15px]">{msg.content}</p>
                  )
                )}
                {!isOld && (
                  <div className={`text-[10px] mt-1 text-right opacity-70 ${msg.role === "user" ? "text-green-200" : "text-[#8696a0]"}`}>
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                )}
              </div>
            </div>
          )})}
          {loading && (
            <div className="flex flex-col items-start w-full px-3 md:px-0 mt-4">
              <div className="p-4 rounded-b-xl rounded-tr-xl flex flex-col gap-3 relative overflow-hidden min-w-[200px]" style={{ background: 'transparent' }}>
                <div className="flex items-center gap-2 mb-1 z-10">
                   <Cpu className="w-4 h-4 text-[#8696a0]" />
                   <span id="loading-step-text" className="text-[11px] font-medium text-[#8696a0]">Generating response...</span>
                </div>
              </div>
            </div>
          )}
          </div>
        <div ref={scrollRef} />
      </div>

      {/* Floating Input Area (WhatsApp style) */}
      <div 
        className="absolute bottom-0 left-0 w-full bg-[#202c33] px-2 pt-3 md:px-4 z-50 shadow-[0_-10px_20px_rgba(0,0,0,0.2)]"
        style={{ paddingBottom: 'calc(0.75rem + env(safe-area-inset-bottom, 12px))' }}
      >
        <form onSubmit={handleSend} className="max-w-5xl mx-auto flex items-center gap-3">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message"
            disabled={loading}
            className="flex-1 lux-input text-[15px]"
          />
          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.9 }}
            type="submit"
            disabled={!input.trim() || loading}
            className="w-11 h-11 bg-[#00a884] text-white rounded-full hover:bg-[#008f6f] transition-all flex items-center justify-center shrink-0 disabled:opacity-50 disabled:hover:bg-[#00a884]"
          >
            <Send className="w-5 h-5 ml-[-2px]" />
          </motion.button>
        </form>
      </div>
    </div>
  );
}

function QuickAction({ icon, label, onClick }: { icon?: React.ReactNode, label: string, onClick: () => void }) {
  return (
    <motion.button 
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="bg-[#202c33] p-3 md:p-4 rounded-xl text-left hover:bg-[#2a3942] transition-colors flex items-center gap-3 text-white border border-[#2a3942] shadow-sm hover:shadow-[0_4px_12px_rgba(0,168,132,0.1)]"
    >
      {icon && <div className="text-[#00a884]">{React.cloneElement(icon as React.ReactElement<any>, { className: 'w-5 h-5' })}</div>}
      <span className="font-semibold text-[13px] md:text-[14px] truncate text-[#d1d7db]">{label}</span>
    </motion.button>
  );
}
