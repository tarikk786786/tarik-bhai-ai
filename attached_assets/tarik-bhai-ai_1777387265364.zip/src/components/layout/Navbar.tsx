import { Link, useNavigate, useLocation } from "react-router-dom";
import { motion } from "motion/react";
import { Phone, LogOut, ArrowLeft } from "lucide-react";
import { useAuth } from "../../lib/useAuth";

export default function Navbar() {
  const { logOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <div className="fixed top-0 left-0 right-0 z-50 flex py-3 px-4 w-full bg-[#202c33]/80 backdrop-blur-md border-b border-[#2a3942]/50 shadow-lg h-[60px]">
      <nav className="w-full max-w-5xl mx-auto flex justify-between items-center">
        <div className="flex items-center gap-3">
          {location.pathname !== '/' && (
            <button 
              onClick={() => navigate('/')}
              className="p-1 text-[#8696a0] hover:text-[#d1d7db] hover:bg-[#2a3942] rounded-full transition-all flex items-center justify-center cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center overflow-hidden relative border border-[#2a3942]">
              <img 
                  src="https://i.ibb.co/MDBBL3ZC/Gemini-Generated-Image-tc1nobtc1nobtc1n.png" 
                  alt="Avatar" 
                  className="w-full h-full object-cover scale-150"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-semibold text-[#e9edef] leading-tight">Tarik Bhai AI</span>
              <span className="text-xs text-[#00a884]">online</span>
            </div>
          </Link>
        </div>
        <div className="flex items-center gap-3">
          <a 
            href="https://wa.me/918984473230"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold text-[#25D366] border border-[#25D366]/40 hover:bg-[#25D366]/10 transition-all cursor-pointer"
          >
            <Phone className="w-3.5 h-3.5 fill-current" />
            <span className="hidden sm:inline">Call Tarik Bhai</span>
          </a>
          <button 
            onClick={logOut}
            className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold text-[#8696a0] border border-[#2a3942] hover:bg-[#2a3942] hover:text-[#d1d7db] transition-all cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5 fill-current" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
