import { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';

function Stars({ count = 5000, depth = 100 }) {
  const ref = useRef<any>(null);
  
  const [positions, colors] = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
       // Distribute stars in a cylinder/tube along the Z axis
      const r = 30 * Math.sqrt(Math.random()) + 1; // Radius
      const theta = Math.random() * 2 * Math.PI;
      const z = (Math.random() - 0.5) * depth;
      
      positions[i * 3] = r * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(theta);
      positions[i * 3 + 2] = z;

      const isGreenish = Math.random() > 0.5;
      if (isGreenish) {
        colors[i * 3] = 0;
        colors[i * 3 + 1] = 0.6 + Math.random() * 0.4;
        colors[i * 3 + 2] = 0.5 + Math.random() * 0.4;
      } else {
        colors[i * 3] = 0.2 + Math.random() * 0.2;
        colors[i * 3 + 1] = 0.6 + Math.random() * 0.4;
        colors[i * 3 + 2] = 0.8 + Math.random() * 0.2;
      }
    }
    return [positions, colors];
  }, [count, depth]);

  useFrame((state, delta) => {
    if (ref.current) {
      // Fly forward
      ref.current.position.z += delta * 12;
      // Slight rotation
      ref.current.rotation.z -= delta * 0.05;
      
      // Loop
      if (ref.current.position.z > depth / 2) {
        ref.current.position.z -= depth;
      }
    }
  });

  return (
    <group ref={ref}>
      <Points positions={positions} colors={colors} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          vertexColors
          size={0.12}
          sizeAttenuation={true}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          opacity={0.8}
        />
      </Points>
    </group>
  );
}

export default function ThreeBackground() {
  return (
    <div className="absolute inset-0 z-0 pointer-events-none w-full h-full opacity-100">
      <div className="absolute inset-0 bg-[#0b141a]"></div>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#005c4b]/10 via-transparent to-transparent mix-blend-screen animate-pulse-slow"></div>
      <Canvas camera={{ position: [0, 0, 0], fov: 75 }}>
        <fog attach="fog" args={['#0b141a', 5, 60]} />
        <Stars depth={120} count={6000} />
        <group position={[0, 0, -60]}>
          <Stars depth={120} count={6000} />
        </group>
      </Canvas>
      <div className="absolute inset-0 bg-gradient-to-b from-[#0b141a] via-transparent to-[#0b141a] opacity-80"></div>
    </div>
  );
}
