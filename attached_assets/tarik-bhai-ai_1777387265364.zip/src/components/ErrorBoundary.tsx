import React, { Component, ErrorInfo, ReactNode } from "react";

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-[#0b141a] text-white p-6 text-center">
          <div className="bg-red-500/10 border border-red-500 rounded-xl p-6 max-w-md">
            <h2 className="text-xl font-bold text-red-500 mb-2">System Failure Detected</h2>
            <p className="text-sm text-red-200 mb-4">
              {this.state.error?.message || "An unexpected error occurred."}
            </p>
            <button
              className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded transition-colors"
              onClick={() => window.location.reload()}
            >
              Reboot Matrix (Reload)
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
