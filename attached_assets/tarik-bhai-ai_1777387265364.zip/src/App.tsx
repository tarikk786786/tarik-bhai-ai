/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/layout/Navbar";
import { useAuth } from "./lib/useAuth";
import ThreeBackground from "./components/ThreeBackground";
import Chat from "./pages/Chat";
import Home from "./pages/Home";

export default function App() {
  const { user, loading, signIn } = useAuth();

  let content;

  if (loading) {
    content = (
      <div className="h-screen w-screen relative flex flex-col items-center justify-center text-white">
        <div className="w-8 h-8 rounded-full border-2 border-[#00a884] border-t-transparent animate-spin mb-4 relative z-10"></div>
      </div>
    );
  } else if (!user) {
    content = (
      <div className="h-screen w-screen relative flex flex-col items-center justify-center text-white p-6 text-center">
        <div className="z-10 relative flex flex-col items-center">
          <h1 className="text-3xl font-bold mb-4 text-[#e9edef]">Welcome to Tarik Bhai AI</h1>
          <p className="text-[#8696a0] mb-8 max-w-md">Sign in with your Google account to access the Nexus AI Protocol and begin chatting.</p>
          <button
            onClick={signIn}
            className="bg-[#00a884] hover:bg-[#008f6f] text-white font-bold py-3 px-6 rounded-full transition-colors flex items-center gap-2 cursor-pointer shadow-[0_0_20px_rgba(0,168,132,0.4)] hover:shadow-[0_0_30px_rgba(0,168,132,0.6)]"
          >
            Sign in with Google
          </button>
        </div>
      </div>
    );
  } else {
    content = (
      <Router>
        <div className="h-[100dvh] flex flex-col relative w-full">
          <Navbar />
          <div className="w-full bg-[#0b141a]/90 backdrop-blur-md border-y border-[#00a884]/40 mt-[60px] py-1.5 z-20 relative flex items-center overflow-hidden shadow-[0_0_15px_rgba(0,168,132,0.15)]">
            <div className="animate-marquee whitespace-nowrap flex items-center">
              <span className="text-[#00a884] font-medium font-mono text-[11px] md:text-xs tracking-widest uppercase opacity-90 mx-8">
                 ⚡ SYSTEM ONLINE // ADVANCED SPACE TECHNOLOGY NEXUS // YOU'VE GOT MAIL // COSMIC PROTOCOL ACTIVE ⚡
              </span>
              <span className="text-[#00a884] font-medium font-mono text-[11px] md:text-xs tracking-widest uppercase opacity-90 mx-8">
                 ⚡ SYSTEM ONLINE // ADVANCED SPACE TECHNOLOGY NEXUS // YOU'VE GOT MAIL // COSMIC PROTOCOL ACTIVE ⚡
              </span>
              <span className="text-[#00a884] font-medium font-mono text-[11px] md:text-xs tracking-widest uppercase opacity-90 mx-8">
                 ⚡ SYSTEM ONLINE // ADVANCED SPACE TECHNOLOGY NEXUS // YOU'VE GOT MAIL // COSMIC PROTOCOL ACTIVE ⚡
              </span>
            </div>
          </div>
          <main className="flex-1 flex flex-col relative z-10 w-full overflow-hidden">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/chat" element={<Chat />} />
            </Routes>
          </main>
        </div>
      </Router>
    );
  }

  return (
    <div className="h-screen w-screen relative bg-[#0b141a]">
      <ThreeBackground />
      <div className="absolute inset-0 z-10">
        {content}
      </div>
    </div>
  );
}
