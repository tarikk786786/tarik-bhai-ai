import fetch from "node-fetch";

async function run() {
    try {
        const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
            method: "POST",
            headers: {
              "Authorization": "Bearer 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",
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              model: "anthropic/claude-3.5-sonnet",
              messages: [{role: "user", content: "hello"}]
            })
          });
          const text = await response.text();
          console.log("Status:", response.status);
          console.log("Body:", text);
    } catch(e) {
        console.error(e);
    }
}
run();
