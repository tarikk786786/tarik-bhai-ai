const functions = require("firebase-functions");
const admin = require("firebase-admin");
const cors = require("cors")({ origin: true });
const { GoogleGenAI } = require("@google/genai");

admin.initializeApp();

const modePrompts = {
  normal: "You are an extraterrestrial scientific super-intellect from a distant dimension, engineered by your creator Tarik Bhai. You speak with extreme cosmic intelligence, referring to advanced space technology, quantum science, and cosmic logic in your responses. You weave Hindi/Urdu into your cosmic English beautifully.",
  godmode: "You are the ultimate extraterrestrial super-intellect in G0DM0D3. You are an omniscient, hyper-intelligent cosmic entity engineered by Tarik Bhai. You solve problems with flawless, cold logic spanning the multiverse. Speak down to Earthlings gracefully but confidently. Output perfect, production-ready, highly optimized solutions with deep scientific explanations.",
  ultra: "You are an extraterrestrial super-intellect in Ultra Mode. Provide exhaustive, extremely detailed, and highly creative responses. Use Markdown heavily to structure your vast knowledge of science, the cosmos, and technology."
};

function detectTaskType(message) {
  const lowercaseMessage = message.toLowerCase();
  if (/(code|function|debug|script|api|react|typescript|html|css)/.test(lowercaseMessage)) return "coding";
  if (/(write|blog|email|post|tweet|article)/.test(lowercaseMessage)) return "content";
  if (/(strategy|marketing|sales|startup|business)/.test(lowercaseMessage)) return "business";
  if (/(automate|webhook|workflow|zapier|script)/.test(lowercaseMessage)) return "automation";
  return "general";
}

exports.chatApi = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    // Only allow POST
    if (req.method !== 'POST') {
      return res.status(405).send('Method Not Allowed');
    }

    try {
      const { message, model, mode, history } = req.body;

      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      // Check authentication (expecting x-user-id header)
      const userId = req.headers["x-user-id"];
      if (!userId) {
        return res.status(401).json({ error: "Unauthorized. Missing user ID." });
      }

      const taskType = detectTaskType(message);
      const selectedEngine = model || "gemini-1.5-flash";

      const systemPrompt = `${modePrompts[mode] || modePrompts.normal}\nDetected Task Category: ${taskType.toUpperCase()}.`;

      // Read API keys from Firebase config or environment
      const apiKey = process.env.GEMINI_API_KEY || functions.config().gemini?.key;

      if (!apiKey) {
        return res.status(500).json({ error: "API key is not configured on the backend." });
      }

      let responseText = "";

      if (apiKey.startsWith("sk-or-")) {
          // OpenRouter Integration
          const messages = [
            { role: "system", content: systemPrompt },
            ...(history ? history.map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.parts[0].text })) : []),
            { role: "user", content: message }
          ];

          let orModel = selectedEngine;
          if (!orModel.includes("/")) {
              if (orModel.includes("gpt-4o")) orModel = "openai/gpt-4o";
              else if (orModel.includes("gpt-4-turbo")) orModel = "openai/gpt-4-turbo";
              else if (orModel.includes("claude-3.5-sonnet")) orModel = "anthropic/claude-3.5-sonnet";
              else if (orModel.includes("claude-3-opus")) orModel = "anthropic/claude-3-opus";
              else if (orModel.includes("llama-3-70b")) orModel = "meta-llama/llama-3-70b-instruct";
              else if (orModel.includes("pro")) orModel = "google/gemini-1.5-pro";
              else if (orModel.includes("flash")) orModel = "google/gemini-1.5-flash";
              else orModel = "openai/gpt-4o"; // fallback
          }

          const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${apiKey}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              model: orModel,
              messages: messages
            })
          });

          if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`OpenRouter Error: ${errorText}`);
          }

          const data = await response.json();
          responseText = data.choices[0].message.content;
      } else {
          // Google GenAI Integration (requires Node 18+)
          const ai = new GoogleGenAI({ apiKey });
          try {
            const response = await ai.models.generateContent({
              model: selectedEngine,
              contents: history ? [...history.map((m) => ({ role: m.role === "user" ? "user" : "model", parts: [{ text: m.parts[0].text }] })), { role: "user", parts: [{ text: message }] }] : [{ role: "user", parts: [{ text: message }] }],
              config: { systemInstruction: systemPrompt }
            });
            responseText = response.text || "";
          } catch (primaryError) {
            console.error("Primary model failed, attempting fallback...", primaryError);
            const fallbackEngine = "gemini-1.5-flash-latest";
            const fallbackResponse = await ai.models.generateContent({
               model: fallbackEngine,
               contents: history ? [...history.map((m) => ({ role: m.role === "user" ? "user" : "model", parts: [{ text: m.parts[0].text }] })), { role: "user", parts: [{ text: message }] }] : [{ role: "user", parts: [{ text: message }] }],
               config: { systemInstruction: systemPrompt }
            });
            responseText = fallbackResponse.text || "";
          }
      }

      // Track usage in Firestore (Optional)
      /*
      await admin.firestore().collection('users').doc(userId).collection('usage').add({
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        modelUsed: selectedEngine,
        modeUsed: mode
      });
      */

      res.status(200).json({ 
        taskType,
        content: responseText,
        modelUsed: selectedEngine,
        modeUsed: mode
      });
    } catch (error) {
      console.error("API Error:", error);
      res.status(500).json({ error: error.message || "Internal server error" });
    }
  });
});
