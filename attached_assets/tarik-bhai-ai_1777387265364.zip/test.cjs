const http = require('http');

const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/api/chat',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-user-id': 'test-user-id'
  }
};

const req = http.request(options, res => {
  console.log(`statusCode: ${res.statusCode}`);
  let data = '';
  res.on('data', d => {
    data += d;
  });
  res.on('end', () => {
    console.log(data);
  });
});

req.on('error', error => {
  console.error(error);
});

req.write(JSON.stringify({
  message: 'Hello, what is your name?',
  model: 'gemini-1.5-flash',
  mode: 'normal',
  history: []
}));
req.end();
